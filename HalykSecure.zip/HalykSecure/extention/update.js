var inp = Array.from(document.querySelectorAll("input.custom-control-input"))
var lab = Array.from(document.querySelectorAll("label.custom-control-label"))


inp.forEach(function(item, i, array){
    item.addEventListener("change", function(){
        if(inp[i].checked){
            lab[i].innerText = 'Вкл.';
        }
        else{
            lab[i].innerText = 'Выкл.';
        }
    })
});
for(let i = 0; i < inp.length; i++){
    if(inp[i].checked){
        lab[i].innerText = 'Вкл.';
    }
    else{
        lab[i].innerText = 'Выкл.';
    }
}